﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotatePlatform : MonoBehaviour {

    public float xRotate;
    public float yRotate;
    public float zRotate;
	
	//Update is called once per frame
    //Used to rotate many objects on multiple or singular axis
	void Update ()
    {
        transform.Rotate(new Vector3(xRotate, yRotate, zRotate) * Time.deltaTime);
		
	}
}
