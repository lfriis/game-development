﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransformPlatform : MonoBehaviour {

    public float speed = 3f;

	//initializing position of platform
	void Start ()
    {
        transform.position = new Vector3(76.5f, 1f, 0.15f);
	}
	
	//On each update call, it will check if the position is within these paramteres
	void Update () {

        //if so, then the direction of the platform will change in the opposite direction
        if ((transform.position.x >= 82f) || (transform.position.x < 76f))
        {
            speed *= -1f;
        }

        transform.Translate(new Vector3(1f, 0f, 0f) * speed * Time.deltaTime);
    }
}
