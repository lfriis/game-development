﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MovePlayer : MonoBehaviour {

    public float speed = 5;
    public Text countText;
    public Text winText;

    Collider objectCollider;
    private Rigidbody sphere;
    private int collectableCount;

    bool colourChangeCollision = false;

    // Use this for initialization
    void Start ()
    {
        sphere = GetComponent<Rigidbody>();
        objectCollider = GetComponent<Collider>();
        collectableCount = 0;
        winText.text = "";
        SetCountText();
	}

    // Fixed update is primarily used for controlling rigid bodies
    void FixedUpdate ()
    {

        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical   = Input.GetAxis("Vertical");

        if (Input.GetKeyDown(KeyCode.Space))
        {
            //multiplying by a factor of 22 to increase jump height
            sphere.AddForce(Vector3.up * (22 * speed));
        }

        Vector3 playerMovement = new Vector3(moveHorizontal, 0f, moveVertical);

        sphere.AddForce(speed * playerMovement);
    }

    void OnTriggerEnter(Collider other)
    {
        //when player object interacts with collectables it will pick them up
        if (other.gameObject.CompareTag("Collectable"))
        {
            other.gameObject.SetActive(false);
            collectableCount++;
            SetCountText();
        }

        //if player object enters end zone, zone colour will change to green to show level completed
        else if (other.gameObject.CompareTag("End Zone"))
        {
            other.transform.gameObject.GetComponent<Renderer>().material.color = Color.green;
            winText.text = "YOU WIN!";
        }

        //safe zone section so player can enter and disable trigger
        else if (other.gameObject.CompareTag("Safe Zone"))
        {
            objectCollider.isTrigger = false;
        }

        //when player object interacts with death zones, it will return it to the starting position
        else
        {
            gameObject.transform.position = new Vector3(3.3f, 1.25f, 0.21f);
        }
    }

    //text function to display amount of collectables and win text if you complete level
    void SetCountText ()
    {
        countText.text = "Collectables: " + collectableCount.ToString();
        if (collectableCount == 18)
        {
            winText.text = "YOU WIN!";
        }
    }

}
