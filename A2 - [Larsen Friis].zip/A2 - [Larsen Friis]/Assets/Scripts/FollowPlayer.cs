﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour {

    public GameObject player;
    private Vector3 offset;

    //setting the offset of the camera the difference of the camera to the player
    void Start()
    {
        offset = transform.position - player.transform.position;
    }

    //as we move our player, the camera is moved to be aligned with the player
    void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
}
