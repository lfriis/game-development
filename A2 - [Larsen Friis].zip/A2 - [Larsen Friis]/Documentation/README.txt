Assignment 2: 3D Platformer

Instructions:
- Collect all collectables or pass into teal end zone to win the game.
- Red objects will kill you and send you back to the beginning
- Blue objects are platforms

Controls:
- Use WASD or arrow keys to move
- Use space bar to jump, use 2 times for double jump

(Documentation Added in script files)
(Was unable to get script working correctly with safe zone so I disabled the game object [Safe zones->safe zone]