﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour {

	public GUIText text;
	private int health = 1000;
	private int damage;
    private int mana = 0;
    private bool healer;

    private bool dead;

	void Start() {
		damage = 0;
        if (this.name == "Boss")
            health = 4000;
        else if (this.name == "Tank")
            health = 3000;
        else if (this.name == "Priest")
        {
            health = 1000;
            healer = true;
            mana = 1000;
        }
        dead = false;
		UpdateScore ();
	}

	public int getHealth() {
		return health;
	}

    public int getDamage()
    {
        return damage;
    }

	public void addDamage(int num) {
		damage += num;
		UpdateScore ();
	}

	public void subHealth(int num) {
		health -= num;
		if (health <= 0) {
			dead = true; //Or a method that prompt the simulation to stop...
			health = 0;
		}
		UpdateScore ();
	}

    public bool deadCheck()
    {
		return dead;
    }

    //The following five methods will be called by mana users
	public void smallHeal(Character[] chars, bool cost)
    {

        chars[Random.Range(0,chars.Length)].subHealth(-15); //Pick random damage dealer or priest, heal 15, reduce mana by 5.
		if(cost) mana -= 5;
    }
	public void bigHeal(Character tank, bool cost)
    {
        tank.subHealth(-20);    //Heal tank by 20, reduce mana by 8
		if(cost) mana -= 8;
    }
    public void manaRegen()
    {
        mana += 2; //Called in Update() of GameController.  Will regen mana by 2 every frame.
    }

	void UpdateScore() {


        //This will show all character's displays, not just the boss'.
		text.text = this.name + " Damage: " + damage + " Health: " + health;
        if (healer) text.text = text.text + " Mana: " + mana;
	}
}
