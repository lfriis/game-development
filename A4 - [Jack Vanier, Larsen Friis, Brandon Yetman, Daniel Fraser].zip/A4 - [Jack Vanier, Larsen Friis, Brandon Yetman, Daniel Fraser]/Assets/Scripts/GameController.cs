﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class GameController : MonoBehaviour {
	private Character boss;
	private Character tank;
	private Character rogue;
	private Character mage;
	private Character druid;
	private Character priest;
    private Character[] allChars;
    private GameObject exitButton;
    private bool lvl1;
    private bool lvl2;
    private bool lvl3;
    private bool scores;
    public GUIText guiOut;
    private int timer;

    void Start() {
        timer = 0;
        lvl1 = false;
        lvl2 = false;
        lvl3 = false;
        scores = false;
        exitButton = GameObject.Find("Menu");
        exitButton.SetActive(false);

        //Get current scene's name
        switch (SceneManager.GetActiveScene().name)
        {
            case "Level1":  lvl1 = true;
                            break;
            case "Level2":  lvl2 = true;
                            break;
            case "Level3":  lvl3 = true;
                            break;
            case "Scores":  scores = true;
                            break;
        }
        
        //Start these values for level1-3
        if (!scores)
        {
            boss = GameObject.Find("Boss").GetComponent<Character>();
            tank = GameObject.Find("Tank").GetComponent<Character>();
            rogue = GameObject.Find("Rogue").GetComponent<Character>();
            mage = GameObject.Find("Mage").GetComponent<Character>();
            druid = GameObject.Find("Druid").GetComponent<Character>();
            priest = GameObject.Find("Priest").GetComponent<Character>();
            allChars = new Character[] { boss, tank, rogue, mage, druid, priest };
        }

        //If we are on the scores screen, display the high scores
        if (scores)
        {
            exitButton.SetActive(true);
            guiOut.text = "\tHigh Scores:\nLEVEL1: Total Boss Damage:\t\t" + PlayerPrefs.GetInt("totalBoss") + "\nLEVEL1: Total Party Damage:\t\t" + PlayerPrefs.GetInt("totalParty");
            guiOut.text += "\n\nLEVEL2: Total Boss Damage:\t\t" + PlayerPrefs.GetInt("totalBoss2") + "\nLEVEL2: Total Party Damage:\t\t" + PlayerPrefs.GetInt("totalParty2");
            guiOut.text += "\n\nLEVEL3: Total Boss Damage:\t\t" + PlayerPrefs.GetInt("totalBoss3") + "\nLEVEL3: Total Party Damage:\t\t" + PlayerPrefs.GetInt("totalParty3");
        } 
	}

	void Update() {
        timer++;
        //If we are on a level, simulate the game.
        if (!scores)
        {

            int totalParty = tank.getDamage() + rogue.getDamage() + mage.getDamage() + druid.getDamage() + priest.getDamage();
            for (int i = 0; i < allChars.Length; ++i) //Checks if anyone's health has reached zero..
            {
                if (allChars[i].deadCheck())
                {
                    if (lvl1)
                    {
                        if (PlayerPrefs.HasKey("totalBoss1") && PlayerPrefs.HasKey("totalParty1"))
                        {
                            if (PlayerPrefs.GetInt("totalBoss1") < boss.getDamage()) PlayerPrefs.SetInt("totalBoss1", boss.getDamage());
                            if (PlayerPrefs.GetInt("totalParty1") < totalParty) PlayerPrefs.SetInt("totalParty1", totalParty);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("totalBoss1", boss.getDamage());
                            PlayerPrefs.SetInt("totalParty1", totalParty);
                        }
                    }
                    else if (lvl2)
                    {
                        if (PlayerPrefs.HasKey("totalBoss2") && PlayerPrefs.HasKey("totalParty2"))
                        {
                            if (PlayerPrefs.GetInt("totalBoss2") < boss.getDamage()) PlayerPrefs.SetInt("totalBoss2", boss.getDamage());
                            if (PlayerPrefs.GetInt("totalParty2") < totalParty) PlayerPrefs.SetInt("totalParty2", totalParty);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("totalBoss2", boss.getDamage());
                            PlayerPrefs.SetInt("totalParty2", totalParty);
                        }
                    }
                    else if (lvl3)
                    {
                        if (PlayerPrefs.HasKey("totalBoss3") && PlayerPrefs.HasKey("totalParty3"))
                        {
                            if (PlayerPrefs.GetInt("totalBoss3") < boss.getDamage()) PlayerPrefs.SetInt("totalBoss3", boss.getDamage());
                            if (PlayerPrefs.GetInt("totalParty3") < totalParty) PlayerPrefs.SetInt("totalParty3", totalParty);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("totalBoss3", boss.getDamage());
                            PlayerPrefs.SetInt("totalParty3", totalParty);
                        }
                    }
                    //Save damages and stuff..

                    PlayerPrefs.Save();
                    Debug.Log(allChars[i].name + " has died");
                    exitButton.SetActive(true);
                    Destroy(this); //Destory this script
                }
            }

            int bossDamage = UnityEngine.Random.Range(5, 21); //Number from 5-20
            int bossDamageTank = UnityEngine.Random.Range(45, 56);
            boss.addDamage(bossDamage + bossDamageTank);
            tank.subHealth(bossDamageTank);
            rogue.subHealth(bossDamage);
            mage.subHealth(bossDamage);
            druid.subHealth(bossDamage);
            priest.subHealth(bossDamage);



            int rogueDamage = UnityEngine.Random.Range(15, 21);
            int mageDamage = UnityEngine.Random.Range(1, 31);
            int druidDamage = UnityEngine.Random.Range(5, 16);
            priest.smallHeal(new Character[] { rogue, mage, druid, priest, priest }, true); //Assuming picking damagers are 20% per each, priest being 40
            priest.bigHeal(tank, true);
            priest.manaRegen();

            tank.addDamage(5);
            rogue.addDamage(rogueDamage);
            mage.addDamage(mageDamage);
            druid.addDamage(druidDamage);


            boss.subHealth(5 + rogueDamage + mageDamage + druidDamage);

            if (lvl2 && tank.getHealth() <= 1500)
            {
                if (UnityEngine.Random.Range(0, 2) == 1)
                {
                    priest.smallHeal(new Character[] { rogue, mage, druid, priest, priest }, false);

                }
                else
                {
                    priest.bigHeal(tank, false);
                }
            }
            if (lvl3)
            {
                boss.addDamage((int)(1 / 100 * (bossDamageTank + bossDamage)));
                tank.subHealth((int)(1 / 100 * (bossDamageTank + bossDamage)));
            }


            //SAVE ALL HEALTHS TO CSV UNDER C:/USERS/APPDATA/LOCALLOW/DEFAULTCOMPANY/A4.../playerHealths.csv AS A STRING..?
            SaveHealths();
        }
    }

    private void SaveHealths()
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file;

        if (lvl1) file = File.Open(Application.persistentDataPath + "/playerHealths1.csv", FileMode.Create);
        else if (lvl2) file = File.Open(Application.persistentDataPath + "/playerHealths2.csv", FileMode.Create);
        else file = File.Open(Application.persistentDataPath + "/playerHealths3.csv", FileMode.Create);

        //PlayerHealths healths = new PlayerHealths(boss.getHealth(), tank.getHealth(), rogue.getHealth(), mage.getHealth(), druid.getHealth(), priest.getHealth());
        //bf.Serialize(file, healths);  This was used to save an object with all of the values...didn't work well?

        //Serialize healths as strings.  Saving as a saved object of PlayerHealths(below) provides weird results...
        bf.Serialize(file, "TimeStep:\t"+timer+"\nBoss:\t"+boss.getHealth()+"\nWarrior:\t"+tank.getHealth()+"\nRogue:\t"+rogue.getHealth()+"\nMage:\t"+mage.getHealth()
            +"\nDruid:\t"+druid.getHealth()+"\nPriest:\t"+priest.getHealth());

        file.Close();
    }
}

//This was for saving the healths as an object with all of the healths as members.. provided weird results in the csv file..
[Serializable]
class PlayerHealths
{
    int bossh;
    int tankh;
    int rogueh;
    int mageh;
    int druidh;
    int priesth;
    public PlayerHealths(int bossHealth, int tankHealth, int rogueHealth, int mageHealth, int druidHealth, int priestHealth)
    {
        bossh = bossHealth;
        tankh = tankHealth;
        rogueh = rogueHealth;
        mageh = mageHealth;
        druidh = druidHealth;
        priesth = priestHealth;
    }
    
}
