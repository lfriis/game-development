﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveIt : MonoBehaviour {

    public float speed = 1f;

	//creating a starting position the script and object can calculate from
	void Start () {
        transform.position = new Vector3(0, 1, 0);
    }
	
    //each second update is called, we will translate the vector in the x-axis each second
    //when the x-axis reaches the parameters, we change the direction by multiplying by a negative
	void Update () {

        if ((transform.position.x >= 3) || (transform.position.x <= -3)) {
            speed *= -1f;
        }

        transform.Translate(new Vector3(1, 0, 0) * speed * Time.deltaTime);
    }
}
