﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResizeIt : MonoBehaviour {

    public float growSpeed = 1f;
    public float size = 2f;
    public float min = 2f;
    public float max = 8f;

    void Start () {

	}
	
	//size is the growth variable
    //each second, all local axis will scale the object by the same value
    //when size reaches the min or max, it will reverse the growth of the object
	void Update () {

        size += growSpeed * Time.deltaTime;

        if (size > max)
        {
            growSpeed = -1f;
        }

        else if (size < min)
        {
            growSpeed = 1f;
        }
        
        transform.localScale = new Vector3 (size, size, size);
    }
}
