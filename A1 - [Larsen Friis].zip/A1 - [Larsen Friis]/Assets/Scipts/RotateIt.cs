﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateIt : MonoBehaviour {

	void Start () {
		
	}
	
    //The object that has this script attached to it, will rotate each second
	void Update () {
        transform.Rotate(new Vector3(30, 60, 90) * Time.deltaTime);
    }
}
