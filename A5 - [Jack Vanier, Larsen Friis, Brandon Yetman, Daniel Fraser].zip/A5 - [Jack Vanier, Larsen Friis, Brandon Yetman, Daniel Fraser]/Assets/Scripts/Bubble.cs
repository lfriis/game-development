﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Bubble : MonoBehaviour
{
    private float rbSpeed = 10f;

	private GameController gc;

	private float bubbleLife;
    private int spawnRate;
    private Vector3 currentDir;
    private Rigidbody rb;

    //Special form of start that is called from spawner, not automatically.  Used to initialize certain things before creation based on tags.
    public void Startup()
    {
        currentDir = transform.forward;
        bubbleLife = 10.0f;
        gc = GameObject.Find("MainObject").GetComponent<GameController>();
        rb = GetComponent<Rigidbody>();

        //If you are a clone, you are to be given a speed.  If you're an origin (prefab), no speed added.
        if (tag=="bubble") rb.AddForce(currentDir * rbSpeed, ForceMode.VelocityChange);
    }

    public void Update()
    {

        //Keep origin object alive, decrease clone's health.
		if (tag != "origin") bubbleLife -= Time.deltaTime;

		if (bubbleLife <= 0.0f) {
			killBubble ();
		}

    }
    
    //if the timed life of the bubble reaches 0, then destroy and increment the amount of bubbles killed.  Never called to kill origin.
    void killBubble()
    {
        if (bubbleLife <= 0.0f)
        {
			Debug.Log ("Destroying a bubble");
			//timedOutBubbles++;
			gc.bubbleTimedOut();
			Destroy(gameObject);
        }
    }

    //On mouse down, if user clicks on bubble, they are destroyed and counter updated
    void OnMouseDown()
    {

        //If left-click on this bubble and given that this bubble is not the origin (though that seems impossible to click), destroy it.
        if (Input.GetMouseButtonDown(0) && tag !="origin")
        {
            Destroy(gameObject);
			gc.destroyedBubble ();
        }
    }

    //When bubbles hit the retaining walls, the reverse their direction back to the viewing field
    
    //There was also an OnTriggerEnter here, but after figuring out the BouceMat problem, the walls simply just needed to be colliders with
    //kinematic rigidbodies that are bouncy.
    
    //There WAS an OnCollisionEnter here, but after figuring out how to use AddForces to the objects, it was no longer necessary to manually change
    //object trajectory.

}
