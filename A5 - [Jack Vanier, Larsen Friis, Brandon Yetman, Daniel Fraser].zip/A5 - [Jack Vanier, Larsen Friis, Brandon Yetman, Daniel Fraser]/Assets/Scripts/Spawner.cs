﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {

    public GameObject origin;
    public GameObject bubble;

    void Start()
    {
        //On start, create the original object from which all objects IN the game field will be cloned from
        origin = GameObject.FindGameObjectWithTag("origin");
        if (origin == null)
        {
            origin = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            origin.AddComponent<Rigidbody>();
            origin.AddComponent<Bubble>();
            origin.tag = "origin";
            origin.name = "origin";
            origin.transform.position = new Vector3(300,300,300);
            origin.GetComponent<Rigidbody>().useGravity = false;
            origin.transform.localScale = new Vector3(2, 2, 2);
            Material newMat = Resources.Load("Materials/BubbleShader") as Material;
            if (newMat == null)
                Debug.Log("new mat is null!!");
            origin.GetComponent<Renderer>().material = newMat;
            origin.GetComponent<Collider>().material = Resources.Load("Materials/BounceMat") as PhysicMaterial;
            origin.GetComponent<Bubble>().Startup(); //Call a special Start()
        }
    }

    public void Update()
    {
        
    }

    public void Spawn ()
    {
        //Instantiates a clone and sets its position and rotation to a spawner, re-tags it, then "starts" its velocity
		bubble = Instantiate (origin, transform.position, transform.rotation);
        bubble.tag = "bubble";
        bubble.GetComponent<Bubble>().Startup();
    }
}