﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PaintController : MonoBehaviour {
    private Ray drawPoint;
    private Camera cam;
    public GameObject original;
    public GameObject redSphere;
    public GameObject blueSphere;
    public GameObject greenSphere;
    public GameObject orangeSphere;
    private Color currentColour;
    private Vector3 lastPoint;
    private int numSpawned;

	// Use this for initialization
	void Start () {
        numSpawned = 0;
        currentColour = new Color(0,0,1);
        lastPoint = new Vector3(300,300,300);  //arbitrary
        cam = GameObject.Find("Main Camera").GetComponent<Camera>();
        
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetMouseButton(0))
        {
            drawPoint = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            Physics.Raycast(drawPoint, out hit);
            
            //Paint on the artboard if a sphere doesn't already exist there (prevent incidental stacking)
            if (Input.mousePosition != lastPoint && hit.transform.gameObject.name == "Artboard")
            {
                
                GameObject current;
                current = Instantiate(original);
                current.tag = "clone";
                current.transform.position = new Vector3(hit.point.x, hit.point.y+1, hit.point.z);
                current.GetComponent<Renderer>().material.color = currentColour;
                lastPoint = Input.mousePosition;
                numSpawned++;
            }

            //Change colours if one of the menu spheres are hit
            else if (hit.transform.gameObject.tag == "colourSphere")
            {
                currentColour = hit.transform.gameObject.GetComponent<Renderer>().material.color;
            }
        }

        //If right click is pressed, whatever sphere is being pointed to will be destroyed
        else if (Input.GetMouseButton(1))
        {
            drawPoint = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            Physics.Raycast(drawPoint, out hit);
            if (hit.transform.gameObject.tag == "clone")
            {
                Destroy(hit.transform.gameObject);
                numSpawned--;
            }
        }
        
    }

    //When the "back" button is pressed to return to the menu, this will check and replace the high score (if necessary) before being destroyed
    void OnDestroy()
    {
        Debug.Log(numSpawned);
        if (PlayerPrefs.HasKey("paintScore"))
        {
            if (PlayerPrefs.GetInt("paintScore") < numSpawned) PlayerPrefs.SetInt("paintScore", numSpawned);
        }
        else PlayerPrefs.SetInt("paintScore", numSpawned);
    }


}