﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scores : MonoBehaviour {

    public GUIText guiOut;

	// Use this for initialization
	void Start () {
        guiOut.text = "HIGH SCORES: \nBubbles:\t" + PlayerPrefs.GetInt("bubbleScore");
        guiOut.text += "\nPainting:\t" + PlayerPrefs.GetInt("paintScore");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
