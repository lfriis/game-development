﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {
	private Spawner script;
	private float spawnTimer = 1.0f; //Spawn new ball every 1 seconds to start
	private float timeElapsed = 0.0f;
    private GameObject backButton;

	public Text bubbleCount;
	public Text gameOver;

	private int timedOutBubbles;
    private int destroyedBubbles;


	// Use this for initialization
	void Start () {
        backButton = GameObject.Find("BacktoMain");
        backButton.SetActive(false);
        timedOutBubbles = 0;
        destroyedBubbles = 0;
		bubbleCount.text = "Bubbles Popped: " + destroyedBubbles;
		gameOver.text = "";

		string spawner = "Spawner ";
		int rand = Random.Range (1, 15);
		Debug.Log ("Coming out of spawner " + rand);
		spawner += rand.ToString();
		script = GameObject.Find (spawner).GetComponent<Spawner> ();
		if (script == null) {
			Debug.Log ("Script is null");
		}
	}
	
	// Update is called once per frame
	void Update () {
		timeElapsed += Time.deltaTime;
		if (timeElapsed >= spawnTimer) {
			timeElapsed = 0.0f;
            spawnTimer -= 0.01f;        //Increase the rate at which bubbles spawn
			string spawner = "Spawner ";
			int rand = Random.Range (1, 15);
			Debug.Log ("Coming out of spawner " + rand);
			spawner += rand.ToString();
			script = GameObject.Find (spawner).GetComponent<Spawner> ();
			if (script == null) {
				Debug.Log ("Script is null");
			}
			script.Spawn ();
		}
	}


    //If a bubble is destroyed, add one to the score and update the text at the top of the screen
	public void destroyedBubble() {
		destroyedBubbles++;
		SetCountText ();
	}

    //If ten bubbles time out (they were not pressed), end the game.
	public void bubbleTimedOut() {
		timedOutBubbles++;
        SetCountText();
        if (timedOutBubbles==10) endGame();
	}

	//Outputting counted bubbles popped to UI
	void SetCountText()
	{
		bubbleCount.text = "Bubbles Popped: " + destroyedBubbles;
	}

    //If 10 bubbles have died, then end game, display button to bring back to main menu.	
    void endGame()
	{
        backButton.SetActive(true);
	    gameOver.text = "          GAME OVER \nTotal Bubbles Popped: " + destroyedBubbles;

        //Check to write new high score.
        if (PlayerPrefs.HasKey("bubbleScore"))
        {
            if (PlayerPrefs.GetInt("bubbleScore") < destroyedBubbles) PlayerPrefs.SetInt("bubbleScore", destroyedBubbles);
        }
        else PlayerPrefs.SetInt("bubbleScore", destroyedBubbles);
        Time.timeScale = 0;
		
	}
}
